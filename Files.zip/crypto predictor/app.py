from flask import Flask, render_template, jsonify, request
from src.lstm_predictor import LSTMCryptoPredictor
import os
from dotenv import load_dotenv

app = Flask(__name__)
load_dotenv()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    symbol = data.get('symbol', 'BTCUSDT')
    timeframe = data.get('timeframe', '1h')
    
    try:
        predictor = LSTMCryptoPredictor(symbol, timeframe)
        result = predictor.predict_next()
        if result:
            return jsonify(result)
        return jsonify({'error': 'Prediction failed'}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/train', methods=['POST'])
def train():
    data = request.json
    symbol = data.get('symbol', 'BTCUSDT')
    timeframe = data.get('timeframe', '1h')
    quick = data.get('quick', True)
    
    try:
        predictor = LSTMCryptoPredictor(symbol, timeframe)
        success = predictor.train(force=True, quick=quick)
        return jsonify({'success': success})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)))