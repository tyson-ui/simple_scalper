# src/__init__.py

# Package version
__version__ = "0.1.0"

# Optional: Explicit imports for public API
from .data_fetcher import CryptoDataFetcher, ExternalAPIPriceFetcher
from .lstm_predictor import LSTMCryptoPredictor
from .real_time_detector import RealTimeSignalDetector
from .trading_simulator import CryptoTradingSimulator

# Optional: Package-level initialization
print(f"Initializing crypto-predictor package v{__version__}")

__all__ = [
    'CryptoDataFetcher',
    'ExternalAPIPriceFetcher',
    'LSTMCryptoPredictor',
    'RealTimeSignalDetector',
    'CryptoTradingSimulator'
]