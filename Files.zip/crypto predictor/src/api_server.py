from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from lstm_predictor import LSTMCryptoPredictor
from data_fetcher import ExternalAPIPriceFetcher

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/predictions/{symbol}")
async def get_predictions(symbol: str):
    predictor = LSTMCryptoPredictor(symbol)
    price_fetcher = ExternalAPIPriceFetcher()
    
    current_price = price_fetcher.get_current_price(symbol)
    prediction = predictor.predict()
    
    return {
        "symbol": symbol,
        "current_price": current_price,
        "prediction": prediction
    }