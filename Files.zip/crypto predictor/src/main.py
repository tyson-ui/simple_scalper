from signal_generator import SignalGenerator
from api_server import app
import uvicorn

if __name__ == "__main__":
    # Start API server
    uvicorn.run(app, host="0.0.0.0", port=8000)
    
    # Or run in prediction mode
    # symbols = ['BTC', 'ETH', 'SOL']
    # generator = SignalGenerator(symbols)
    # while True:
    #     signals = generator.generate_signals()
    #     print(signals)
    #     time.sleep(60)