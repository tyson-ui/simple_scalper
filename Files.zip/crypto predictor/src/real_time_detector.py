class RealTimeSignalDetector:
    def __init__(self, symbol: str):
        self.symbol = symbol
        self.price_buffer = []
        self.MAX_BUFFER = 20
        
    def update_prices(self, new_price: float):
        """Update price buffer and detect micro-movements"""
        self.price_buffer.append(new_price)
        if len(self.price_buffer) > self.MAX_BUFFER:
            self.price_buffer.pop(0)
            
    def detect_micro_trend(self) -> Optional[int]:
        """Detect small price movements (1-2%)"""
        if len(self.price_buffer) < 5:
            return None
            
        changes = [
            (self.price_buffer[i] - self.price_buffer[i-1])/self.price_buffer[i-1]
            for i in range(1, len(self.price_buffer))
        ]
        
        # Check for consistent micro-trend
        if all(c > 0.002 for c in changes[-3:]):  # 0.2% increase x3
            return 1
        elif all(c < -0.002 for c in changes[-3:]):
            return -1
        return 0