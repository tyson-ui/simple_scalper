import requests
from textblob import TextBlob
from config import Config

class SentimentAnalyzer:
    def __init__(self):
        self.api_key = Config.CRYPTO_PANIC_API_KEY

    def get_cryptopanic_sentiment(self):
        url = f"https://cryptopanic.com/api/v1/posts/?auth_token={self.api_key}"
        response = requests.get(url)
        return response.json()

    def analyze_sentiment(self, text):
        analysis = TextBlob(text)
        return analysis.sentiment.polarity