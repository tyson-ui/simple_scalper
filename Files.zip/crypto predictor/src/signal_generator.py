from typing import Dict
from lstm_predictor import LSTMCryptoPredictor
from real_time_detector import RealTimeSignalDetector

class SignalGenerator:
    def __init__(self, symbols: list):
        self.symbols = symbols
        self.predictors = {sym: LSTMCryptoPredictor(sym) for sym in symbols}
        self.detectors = {sym: RealTimeSignalDetector(sym) for sym in symbols}

    def generate_signals(self) -> Dict:
        signals = {}
        for symbol in self.symbols:
            prediction = self.predictors[symbol].predict()
            micro_trend = self.detectors[symbol].detect_micro_trend()
            
            # Your signal generation logic here
            signals[symbol] = {
                'prediction': prediction,
                'micro_trend': micro_trend,
                'signal': self._generate_signal(prediction, micro_trend)
            }
        return signals