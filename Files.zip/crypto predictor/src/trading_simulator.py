from typing import List, Dict
from datetime import datetime
import logging
from .data_fetcher import CryptoDataFetcher, ExternalAPIPriceFetcher

class CryptoTradingSimulator: