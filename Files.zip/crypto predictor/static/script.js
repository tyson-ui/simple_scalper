// Sample data - in a real app, this would come from your backend API
const cryptoData = [
    { symbol: 'BTC', name: 'Bitcoin', price: 61234.56, change: 2.34, marketCap: 1.2e12 },
    { symbol: 'ETH', name: 'Ethereum', price: 3421.78, change: -1.23, marketCap: 412e9 },
    { symbol: 'BNB', name: 'Binance Coin', price: 523.45, change: 0.56, marketCap: 89e9 },
    { symbol: 'SOL', name: 'Solana', price: 143.21, change: 5.67, marketCap: 61e9 },
    { symbol: 'XRP', name: 'Ripple', price: 0.5321, change: -0.34, marketCap: 28e9 }
];

const sentimentData = {
    value: 68, // 0-100 scale (0=very bearish, 100=very bullish)
    news: [
        { title: 'Bitcoin ETF Approval Expected This Week', source: 'CoinDesk', sentiment: 'positive' },
        { title: 'Regulatory Crackdown on Stablecoins in Europe', source: 'CryptoNews', sentiment: 'negative' },
        { title: 'Ethereum Upgrade Scheduled for Next Month', source: 'Decrypt', sentiment: 'positive' },
        { title: 'Market Analysts Predict Consolidation Phase', source: 'Bloomberg Crypto', sentiment: 'neutral' }
    ]
};

const tradingSignals = [
    { symbol: 'BTC', signal: 'BUY', currentPrice: 61234.56, entry: 61000, takeProfit: 62500, stopLoss: 59800, confidence: 85 },
    { symbol: 'ETH', signal: 'SELL', currentPrice: 3421.78, entry: 3430, takeProfit: 3350, stopLoss: 3480, confidence: 72 },
    { symbol: 'SOL', signal: 'BUY', currentPrice: 143.21, entry: 142.5, takeProfit: 148.0, stopLoss: 138.0, confidence: 63 },
    { symbol: 'XRP', signal: 'HOLD', currentPrice: 0.5321, entry: '-', takeProfit: '-', stopLoss: '-', confidence: 45 }
];

// Initialize the dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    loadPriceData();
    loadSentimentData();
    loadTradingSignals();
    
    // In a real app, you would set up periodic refreshes
    // setInterval(loadPriceData, 60000); // Refresh every minute
});

function loadPriceData() {
    const tableBody = document.getElementById('price-table');
    tableBody.innerHTML = '';
    
    cryptoData.forEach(crypto => {
        const row = document.createElement('tr');
        
        const changeClass = crypto.change >= 0 ? 'up' : 'down';
        const changeIcon = crypto.change >= 0 ? '↑' : '↓';
        
        row.innerHTML = `
            <td><strong>${crypto.symbol}</strong> - ${crypto.name}</td>
            <td>$${crypto.price.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
            <td class="${changeClass}">${changeIcon} ${Math.abs(crypto.change)}%</td>
            <td>$${(crypto.marketCap / 1e9).toFixed(2)}B</td>
        `;
        
        tableBody.appendChild(row);
    });
}

function loadSentimentData() {
    const sentimentValue = sentimentData.value;
    const sentimentBar = document.getElementById('sentiment-bar');
    const sentimentText = document.getElementById('sentiment-value');
    
    // Update sentiment meter
    sentimentBar.style.width = `${sentimentValue}%`;
    
    // Set sentiment text and color
    let sentimentLabel, textClass;
    if (sentimentValue > 70) {
        sentimentLabel = 'Very Bullish';
        textClass = 'positive';
    } else if (sentimentValue > 55) {
        sentimentLabel = 'Bullish';
        textClass = 'positive';
    } else if (sentimentValue > 45) {
        sentimentLabel = 'Neutral';
        textClass = 'neutral';
    } else if (sentimentValue > 30) {
        sentimentLabel = 'Bearish';
        textClass = 'negative';
    } else {
        sentimentLabel = 'Very Bearish';
        textClass = 'negative';
    }
    
    sentimentText.textContent = `${sentimentLabel} (${sentimentValue}/100)`;
    sentimentText.className = `sentiment-value ${textClass}`;
    
    // Load news feed
    const newsList = document.getElementById('news-list');
    newsList.innerHTML = '';
    
    sentimentData.news.forEach(item => {
        const newsItem = document.createElement('li');
        newsItem.className = `list-group-item news-item ${item.sentiment}`;
        
        newsItem.innerHTML = `
            <div class="news-title">${item.title}</div>
            <div class="news-source">Source: ${item.source}</div>
        `;
        
        newsList.appendChild(newsItem);
    });
}

function loadTradingSignals() {
    const signalsTable = document.getElementById('signals-table');
    signalsTable.innerHTML = '';
    
    tradingSignals.forEach(signal => {
        const row = document.createElement('tr');
        
        // Determine row class based on signal
        if (signal.signal === 'BUY') {
            row.className = 'buy-signal';
        } else if (signal.signal === 'SELL') {
            row.className = 'sell-signal';
        }
        
        // Determine confidence class
        let confidenceClass = '';
        if (signal.confidence >= 75) {
            confidenceClass = 'confidence-high';
        } else if (signal.confidence >= 50) {
            confidenceClass = 'confidence-medium';
        } else {
            confidenceClass = 'confidence-low';
        }
        
        row.innerHTML = `
            <td><strong>${signal.symbol}</strong></td>
            <td><span class="badge ${signal.signal === 'BUY' ? 'bg-success' : signal.signal === 'SELL' ? 'bg-danger' : 'bg-secondary'}">${signal.signal}</span></td>
            <td>$${signal.currentPrice.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
            <td>${typeof signal.entry === 'number' ? '$' + signal.entry.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}) : signal.entry}</td>
            <td>${typeof signal.takeProfit === 'number' ? '$' + signal.takeProfit.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}) : signal.takeProfit}</td>
            <td>${typeof signal.stopLoss === 'number' ? '$' + signal.stopLoss.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}) : signal.stopLoss}</td>
            <td class="${confidenceClass}">${signal.confidence}%</td>
        `;
        
        signalsTable.appendChild(row);
    });
}